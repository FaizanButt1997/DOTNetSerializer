﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace ConsoleAppDotNetCoreTest
{
    public static class PHPSerializer
    {
        public static T Deserialize<T>(string serializedData) where T : class, new()
        {
            if (string.IsNullOrEmpty(serializedData))
                throw new ArgumentNullException(nameof(serializedData), "Serialized data cannot be null or empty.");

            var result = new Dictionary<string, object>();

            try
            {
                var regex = new Regex(@"(?<type>[a-z]):(?<length>\d+):(?<key>[^;]*?);(?<value>.*?)(?=;|$)", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                var matches = regex.Matches(serializedData);

                int index = 0;
                while (index < serializedData.Length)
                {
                    var typeMatch = regex.Match(serializedData, index);
                    if (!typeMatch.Success)
                        break;

                    var type = typeMatch.Groups["type"].Value;
                    var length = int.Parse(typeMatch.Groups["length"].Value);
                    var key = typeMatch.Groups["key"].Value.Trim('"');
                    var value = typeMatch.Groups["value"].Value.TrimEnd(';');

                    switch (type)
                    {
                        case "s": // String
                            value = UnescapeString(value);
                            result[key] = value;
                            break;

                        case "i": // Integer
                            result[key] = int.Parse(value);
                            break;

                        case "b": // Boolean
                            result[key] = value == "1";
                            break;

                        case "a": // Array
                            result[key] = ParseArray(value);
                            break;

                        case "o": // Object (handle if necessary)
                                  // Handle objects if needed
                            break;

                        default:
                            throw new NotSupportedException($"Unsupported type '{type}' found in serialized data.");
                    }

                    index = typeMatch.Index + typeMatch.Length;
                }

                var obj = new T();
                var properties = typeof(T).GetProperties();
                foreach (var property in properties)
                {
                    if (result.TryGetValue(property.Name.ToLower(), out var value))
                    {
                        property.SetValue(obj, Convert.ChangeType(value, property.PropertyType));
                    }
                }
                return obj;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to deserialize data.", ex);
            }
        }

        private static List<string> ParseArray(string arrayData)
        {
            var array = new List<string>();
            var regex = new Regex(@"(?<key>\d+):(?<type>[a-z]):(?<length>\d+):(?<value>.*?)(?=;|$)", RegexOptions.IgnoreCase | RegexOptions.Singleline);

            var matches = regex.Matches(arrayData);
            foreach (Match match in matches)
            {
                var key = int.Parse(match.Groups["key"].Value);
                var type = match.Groups["type"].Value;
                var length = int.Parse(match.Groups["length"].Value);
                var value = match.Groups["value"].Value.TrimEnd(';');

                if (type == "s") // String
                {
                    value = UnescapeString(value);
                    array.Add(value);
                }
                else
                {
                    throw new NotSupportedException($"Unsupported type '{type}' found in array data.");
                }
            }

            return array;
        }

        private static string UnescapeString(string value)
        {
            // Remove surrounding quotes
            if (value.StartsWith("\"") && value.EndsWith("\""))
            {
                value = value.Substring(1, value.Length - 2);
            }

            // Handle escaped quotes and backslashes
            value = value.Replace("\\\"", "\"").Replace("\\\\", "\\");

            return value;
        }
    }
}
