﻿<?php
// Sample data to serialize
$data = array(
    'name' => 'John Doe',
    'age' => 30,
    'is_active' => true,
    'roles' => array('admin', 'user')
);

// Serialize the data
$serializedData = serialize($data);

// Output the serialized data
echo $serializedData;
