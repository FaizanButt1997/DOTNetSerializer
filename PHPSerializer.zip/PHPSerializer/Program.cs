﻿using Enyim.Caching;
using Enyim.Caching.Configuration;
using Enyim.Caching.Memcached;
using PHPSerializer;
using PhpSerializerNET;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace PHPSerializerApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                const string serializedPhpData = "a:4:{s:4:\"name\";s:8:\"John Doe\";s:3:\"age\";i:30;s:9:\"is_active\";b:1;s:5:\"roles\";a:2:{i:0;s:5:\"admin\";i:1;s:4:\"user\";}}";

                // Uncomment the following block if you want to use Memcached

                #region MemcachedConfiguration

                // Configure Memcached client
                var memcachedConfig = new MemcachedClientConfiguration
                {
                    Servers = { new IPEndPoint(IPAddress.Parse("127.0.0.1"), 11211) },
                    Protocol = MemcachedProtocol.Binary // Use Binary protocol
                };

                var memcachedClient = new MemcachedClient(memcachedConfig);

                // Example usage of Memcached client
                // var cachedValue = memcachedClient.Get("test_key");
                // Console.WriteLine("Cached Value: " + cachedValue);

                #endregion

                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Serialized PHP String:");
                Console.ResetColor();
                Console.WriteLine();
                Console.WriteLine(serializedPhpData);

                // Deserialize and display PHP serialized data
                ProcessSerializedData(serializedPhpData);
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("An error occurred: " + ex.Message);
                Console.ResetColor();
            }

            Console.ReadKey();
        }

        private static void ProcessSerializedData(string serializedData)
        {
            try
            {
                // Deserialize the PHP serialized data
                var deserializedData = PhpSerializer.Deserialize(serializedData);

                // Map the deserialized data to UserData
                var userData = ConvertToUserData(deserializedData);

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine();
                Console.WriteLine("Deserialized Result:");
                Console.WriteLine();
                Console.ResetColor();

                if (userData != null)
                {
                    Console.WriteLine($"Name: {userData.Name}");
                    Console.WriteLine($"Age: {userData.Age}");
                    Console.WriteLine($"Is Active: {userData.IsActive}");
                    Console.WriteLine($"Roles: {string.Join(", ", userData.Roles)}");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Deserialization failed or data is null.");
                    Console.ResetColor();
                }
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Failed to process serialized data: " + ex.Message);
                Console.ResetColor();
            }
        }

        private static UserData ConvertToUserData(object deserializedData)
        {
            // Convert deserialized data to dictionary
            var dataDictionary = ConvertToDictionary(deserializedData);

            // Create UserData instance
            var userData = new UserData();

            if (dataDictionary != null)
            {
                // Map values to UserData properties
                if (dataDictionary.TryGetValue("name", out var name))
                    userData.Name = name.ToString();

                if (dataDictionary.TryGetValue("age", out var age) && int.TryParse(age.ToString(), out var ageValue))
                    userData.Age = ageValue;

                if (dataDictionary.TryGetValue("is_active", out var isActive) && bool.TryParse(isActive.ToString(), out var isActiveValue))
                    userData.IsActive = isActiveValue;

                if (dataDictionary.TryGetValue("roles", out var roles) && roles is List<object> rolesList)
                    userData.Roles = rolesList.Cast<string>().ToList();
            }

            return userData;
        }

        private static IDictionary<string, object> ConvertToDictionary(object obj)
        {
            if (obj is IDictionary<string, object> dictionary)
            {
                return dictionary;
            }
            else if (obj is IDictionary)
            {
                var dict = new Dictionary<string, object>();
                foreach (DictionaryEntry entry in (IDictionary)obj)
                {
                    dict[entry.Key.ToString()] = entry.Value;
                }
                return dict;
            }
            else if (obj is IEnumerable enumerable)
            {
                var list = new List<object>();
                foreach (var item in enumerable)
                {
                    list.Add(item);
                }
                return new Dictionary<string, object> { { "array", list } };
            }
            return null;
        }
    }

}
